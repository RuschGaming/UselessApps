﻿Lazy helper How To's

 - Download LazyHelper.zip and extract it. 
 - Copy both files into your bot directory.
 - Make sure you have Node.js Installed. 
 - Run LazyHelper.bat and follow the guide.
 - Once done you can run Start.bat to run your bot. 


I made these 2 scripts for myself and decided to share it with everyone. 



